surname = str(input('what is your surname? '))
age = int(input('how old are you? '))
if age < 18:
    print('go to school,', surname)
else:
    print('welcome on board, mr(s)', surname)


