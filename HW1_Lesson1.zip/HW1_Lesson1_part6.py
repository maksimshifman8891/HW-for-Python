a = int(input('Введите a: '))
b = int(input("Введите b:"))
k = 1
while a <= b:
    k = k + 1
    a = 1.1 * a
print("k = ", k)